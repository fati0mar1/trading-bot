import unittest
from dataclasses import replace
from pathlib import Path
from tempfile import TemporaryDirectory

import numpy as np
import pandas as pd

from config import CostConfig, LIVE_TRADING_AVAILABLE, PAPER_MODE, RiskConfig
from execution import DryRunExecution, OrderRequest
from portfolio_simulator import simulate_portfolio
from strategy.costs import net_trade_return
from strategy.indicators import rsi
from strategy.metrics import calculate_metrics
from strategy.parameters import StrategyParams
from strategy.risk import position_size
from strategy.signals import build_features


def sample_data(rows: int = 360) -> pd.DataFrame:
    index = pd.bdate_range("2020-01-01", periods=rows)
    x = np.arange(rows, dtype=float)
    close = 100 + x * 0.08 + np.sin(x / 3) * 2
    # Persistent step-ups create several unambiguous breakout days.
    for position in (80, 160, 240, 320):
        if position < rows:
            close[position:] += 4.0
    open_ = close * (1 + np.sin(x / 5) * 0.001)
    high = np.maximum(open_, close) + 0.8
    low = np.minimum(open_, close) - 0.8
    volume = np.full(rows, 1_000_000.0)
    volume[::13] = 2_500_000.0
    for position in (80, 160, 240, 320):
        if position < rows:
            volume[position] = 3_000_000.0
    return pd.DataFrame(
        {"Open": open_, "High": high, "Low": low, "Close": close, "Volume": volume},
        index=index,
    )


def permissive_params() -> StrategyParams:
    return StrategyParams(
        ema_fast=3,
        ema_slow=8,
        regime_sma=20,
        rsi_period=5,
        rsi_low=0,
        rsi_high=100,
        volume_window=5,
        volume_multiplier=1.0,
        breakout_window=5,
        atr_period=5,
        min_atr_pct=0.001,
        max_atr_pct=0.20,
        require_market_regime=False,
    )


class CoreTests(unittest.TestCase):
    def test_release_is_paper_only(self):
        self.assertTrue(PAPER_MODE)
        self.assertFalse(LIVE_TRADING_AVAILABLE)

    def test_execution_adapter_records_but_never_sends(self):
        with TemporaryDirectory() as directory:
            path = Path(directory) / "orders.jsonl"
            receipt = DryRunExecution(path).submit(
                OrderRequest("AAPL", "BUY", 2, "unit test")
            )
            self.assertEqual(receipt.status, "RECORDED_NOT_SENT")
            self.assertTrue(path.exists())

    def test_rsi_edge_cases(self):
        self.assertEqual(rsi(pd.Series(range(30), dtype=float), 5).iloc[-1], 100)
        self.assertEqual(rsi(pd.Series([1.0] * 30), 5).iloc[-1], 50)

    def test_signal_has_no_future_leak(self):
        data = sample_data()
        short = build_features(data.iloc[:280], permissive_params())
        full = build_features(data, permissive_params())
        pd.testing.assert_series_equal(
            short["ENTRY_SIGNAL"], full.loc[short.index, "ENTRY_SIGNAL"]
        )

    def test_costs_reduce_return(self):
        gross = 110 / 100 - 1
        net = net_trade_return(100, 110, CostConfig(10, 1))
        self.assertLess(net, gross)

    def test_position_size_obeys_caps(self):
        shares = position_size(
            equity=10_000,
            cash=10_000,
            entry_price=100,
            distance_to_stop=5,
            current_exposure=0,
            risk=RiskConfig(),
        )
        self.assertLessEqual(shares * 100, 10_000 * RiskConfig().max_position_pct)
        self.assertLessEqual(shares * 5, 10_000 * RiskConfig().risk_per_trade)

    def test_metrics_use_equity_curve(self):
        index = pd.bdate_range("2024-01-01", periods=4)
        metrics = calculate_metrics(pd.Series([100, 110, 99, 105], index=index), [])
        self.assertAlmostEqual(metrics["total_return"], 0.05)
        self.assertAlmostEqual(metrics["max_drawdown"], -0.10)

    def test_entry_day_stop_is_processed(self):
        data = sample_data()
        params = permissive_params()
        signals = build_features(data, params)
        signal_positions = np.flatnonzero(signals["ENTRY_SIGNAL"].to_numpy())
        self.assertGreater(len(signal_positions), 0, "fixture must produce a signal")
        signal_position = int(signal_positions[0])
        entry_position = signal_position + 1
        shocked = data.copy()
        shocked.iloc[entry_position, shocked.columns.get_loc("Low")] = 1.0
        result = simulate_portfolio(
            {"TEST": shocked},
            strategy=params,
            risk=replace(RiskConfig(), max_holding_days=5),
        )
        same_day_stops = result.trades[
            (result.trades["exit_reason"] == "HARD_STOP")
            & (result.trades["entry_date"] == result.trades["exit_date"])
        ]
        self.assertGreaterEqual(len(same_day_stops), 1)

    def test_large_gap_activates_loss_circuit_breaker(self):
        data = sample_data()
        params = permissive_params()
        signals = build_features(data, params)
        signal_position = int(np.flatnonzero(signals["ENTRY_SIGNAL"].to_numpy())[0])
        entry_position = signal_position + 1
        shocked = data.copy()
        # The order enters at the normal open, then the day's low collapses
        # through the stop. This creates a realized loss large enough to trip
        # the deliberately tiny test-only daily-loss threshold.
        shocked.iloc[entry_position, shocked.columns.get_loc("Low")] = 1.0
        shocked.iloc[entry_position, shocked.columns.get_loc("Close")] = 1.0
        result = simulate_portfolio(
            {"TEST": shocked},
            strategy=params,
            risk=replace(RiskConfig(), max_daily_loss=0.001, max_drawdown=0.50),
        )
        self.assertTrue(result.halted)
        self.assertEqual(result.halt_reason, "MAX_DAILY_LOSS")

    def test_holding_period_counts_entry_day(self):
        result = simulate_portfolio(
            {"TEST": sample_data()},
            strategy=permissive_params(),
            risk=replace(
                RiskConfig(),
                max_holding_days=3,
                trailing_atr_multiplier=100.0,
            ),
        )
        timed = result.trades[result.trades["exit_reason"] == "TIME_EXIT"]
        self.assertGreater(len(timed), 0)
        self.assertTrue((timed["bars_held"] == 3).all())


if __name__ == "__main__":
    unittest.main()
