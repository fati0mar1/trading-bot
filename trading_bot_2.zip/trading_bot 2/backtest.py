"""Download historical data and run the shared paper portfolio simulator."""

from pathlib import Path
from typing import Iterable

import pandas as pd

from config import BENCHMARK_TICKER, CostConfig, RiskConfig
from data import download_daily_bars, download_universe
from portfolio_simulator import SimulationResult, simulate_portfolio
from strategy.parameters import StrategyParams


def format_metrics(metrics: dict[str, float | int]) -> str:
    percent_fields = {
        "total_return",
        "cagr",
        "annual_volatility",
        "max_drawdown",
        "win_rate",
        "average_trade",
    }
    labels = {
        "starting_equity": "Starting equity",
        "ending_equity": "Ending equity",
        "total_return": "Total return",
        "cagr": "Annualized return (CAGR)",
        "annual_volatility": "Annual volatility",
        "sharpe_ratio": "Sharpe ratio",
        "sortino_ratio": "Sortino ratio",
        "max_drawdown": "Maximum drawdown",
        "trades": "Completed trades",
        "win_rate": "Win rate",
        "profit_factor": "Profit factor",
        "average_trade": "Average trade",
    }
    lines = []
    for key, label in labels.items():
        value = metrics[key]
        if key in {"starting_equity", "ending_equity"}:
            rendered = f"${float(value):,.2f}"
        elif key in percent_fields:
            rendered = f"{float(value) * 100:.2f}%"
        elif key == "trades":
            rendered = str(int(value))
        else:
            rendered = "∞" if value == float("inf") else f"{float(value):.2f}"
        lines.append(f"{label:28} {rendered}")
    return "\n".join(lines)


def run_backtest(
    tickers: Iterable[str],
    *,
    start: str,
    end: str | None = None,
    strategy: StrategyParams | None = None,
    risk: RiskConfig | None = None,
    costs: CostConfig | None = None,
    output_directory: str | Path | None = None,
) -> SimulationResult:
    market_data, errors = download_universe(tickers, start, end)
    if errors:
        print("\nSymbols skipped because data could not be loaded:")
        for ticker, message in errors.items():
            print(f"  {ticker}: {message}")
    if not market_data:
        raise RuntimeError("No symbols produced usable market data")

    benchmark = download_daily_bars(BENCHMARK_TICKER, start, end)
    result = simulate_portfolio(
        market_data,
        benchmark_data=benchmark,
        strategy=strategy,
        risk=risk,
        costs=costs,
    )
    print("\n===== PAPER BACKTEST RESULTS =====")
    print(format_metrics(result.metrics))
    if result.halted:
        print(f"Circuit breaker triggered: {result.halt_reason}")

    if output_directory is not None:
        destination = Path(output_directory)
        destination.mkdir(parents=True, exist_ok=True)
        result.equity_curve.to_csv(destination / "equity_curve.csv")
        result.trades.to_csv(destination / "trades.csv", index=False)
        pd.DataFrame([result.metrics]).to_csv(destination / "metrics.csv", index=False)
        print(f"Saved CSV results in: {destination.resolve()}")
    return result
