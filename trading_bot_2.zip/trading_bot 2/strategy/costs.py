"""Centralized fill-price and commission calculations."""

from config import CostConfig


def buy_fill(raw_price: float, costs: CostConfig) -> float:
    """A buy receives a slightly worse price because of slippage."""
    return float(raw_price) * (1 + costs.slippage_bps / 10_000)


def sell_fill(raw_price: float, costs: CostConfig) -> float:
    """A sell receives a slightly worse price because of slippage."""
    return float(raw_price) * (1 - costs.slippage_bps / 10_000)


def commission(notional: float, costs: CostConfig) -> float:
    return abs(float(notional)) * costs.commission_bps / 10_000


def net_trade_return(entry_raw: float, exit_raw: float, costs: CostConfig) -> float:
    entry = buy_fill(entry_raw, costs)
    exit_ = sell_fill(exit_raw, costs)
    entry_total = entry + commission(entry, costs)
    exit_total = exit_ - commission(exit_, costs)
    return exit_total / entry_total - 1
