"""Validated parameters for the long-only daily-bar strategy."""

from dataclasses import dataclass


@dataclass(frozen=True)
class StrategyParams:
    ema_fast: int = 20
    ema_slow: int = 100
    regime_sma: int = 200
    rsi_period: int = 14
    rsi_low: float = 50.0
    rsi_high: float = 72.0
    volume_window: int = 20
    volume_multiplier: float = 1.20
    breakout_window: int = 20
    atr_period: int = 14
    min_atr_pct: float = 0.005
    max_atr_pct: float = 0.08
    require_market_regime: bool = True

    def __post_init__(self) -> None:
        integer_fields = (
            "ema_fast",
            "ema_slow",
            "regime_sma",
            "rsi_period",
            "volume_window",
            "breakout_window",
            "atr_period",
        )
        if any(getattr(self, field) < 2 for field in integer_fields):
            raise ValueError("indicator windows must be at least 2")
        if self.ema_fast >= self.ema_slow:
            raise ValueError("ema_fast must be smaller than ema_slow")
        if not 0 <= self.rsi_low < self.rsi_high <= 100:
            raise ValueError("RSI limits must satisfy 0 <= low < high <= 100")
        if self.volume_multiplier <= 0:
            raise ValueError("volume_multiplier must be positive")
        if not 0 < self.min_atr_pct < self.max_atr_pct < 1:
            raise ValueError("ATR percentage limits are invalid")
