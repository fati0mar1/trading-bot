"""Causal indicators: every row uses only that row and earlier rows."""

import numpy as np
import pandas as pd


def ema(values: pd.Series, span: int) -> pd.Series:
    if span < 2:
        raise ValueError("span must be at least 2")
    return values.astype(float).ewm(span=span, adjust=False).mean()


def sma(values: pd.Series, window: int) -> pd.Series:
    if window < 2:
        raise ValueError("window must be at least 2")
    return values.astype(float).rolling(window=window, min_periods=window).mean()


def rsi(close: pd.Series, period: int = 14) -> pd.Series:
    """Wilder RSI with explicit handling of all-up, all-down, and flat data."""
    if period < 2:
        raise ValueError("period must be at least 2")
    delta = close.astype(float).diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.ewm(alpha=1 / period, adjust=False, min_periods=period).mean()
    avg_loss = loss.ewm(alpha=1 / period, adjust=False, min_periods=period).mean()
    relative_strength = avg_gain / avg_loss
    result = 100 - 100 / (1 + relative_strength)
    result = result.mask((avg_loss == 0) & (avg_gain > 0), 100.0)
    result = result.mask((avg_gain == 0) & (avg_loss > 0), 0.0)
    return result.mask((avg_gain == 0) & (avg_loss == 0), 50.0)


def true_range(data: pd.DataFrame) -> pd.Series:
    previous_close = data["Close"].shift(1)
    ranges = pd.concat(
        [
            data["High"] - data["Low"],
            (data["High"] - previous_close).abs(),
            (data["Low"] - previous_close).abs(),
        ],
        axis=1,
    )
    return ranges.max(axis=1)


def atr(data: pd.DataFrame, period: int = 14) -> pd.Series:
    """Wilder-style Average True Range."""
    if period < 2:
        raise ValueError("period must be at least 2")
    return true_range(data).ewm(
        alpha=1 / period, adjust=False, min_periods=period
    ).mean()


def volume_ratio(volume: pd.Series, window: int = 20) -> pd.Series:
    if window < 2:
        raise ValueError("window must be at least 2")
    average = volume.astype(float).rolling(window=window, min_periods=window).mean()
    return volume.astype(float) / average.replace(0, np.nan)
