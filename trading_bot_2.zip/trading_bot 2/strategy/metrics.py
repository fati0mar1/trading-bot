"""Performance metrics calculated from the portfolio equity curve and trades."""

from dataclasses import asdict
from typing import Iterable

import numpy as np
import pandas as pd


def max_drawdown(equity: pd.Series) -> float:
    if equity.empty:
        return 0.0
    return float((equity / equity.cummax() - 1).min())


def calculate_metrics(
    equity: pd.Series,
    trades: Iterable[object],
    annual_risk_free_rate: float = 0.0,
) -> dict[str, float | int]:
    equity = equity.dropna().astype(float)
    trade_rows = [asdict(t) if hasattr(t, "__dataclass_fields__") else dict(t) for t in trades]
    if equity.empty:
        return {
            "starting_equity": 0.0,
            "ending_equity": 0.0,
            "total_return": 0.0,
            "cagr": 0.0,
            "annual_volatility": 0.0,
            "sharpe_ratio": 0.0,
            "sortino_ratio": 0.0,
            "max_drawdown": 0.0,
            "trades": 0,
            "win_rate": 0.0,
            "profit_factor": 0.0,
            "average_trade": 0.0,
        }

    daily = equity.pct_change().replace([np.inf, -np.inf], np.nan).dropna()
    total_return = equity.iloc[-1] / equity.iloc[0] - 1
    elapsed_years = max((equity.index[-1] - equity.index[0]).days / 365.25, 1 / 365.25)
    cagr = (equity.iloc[-1] / equity.iloc[0]) ** (1 / elapsed_years) - 1
    volatility = float(daily.std(ddof=1) * np.sqrt(252)) if len(daily) > 1 else 0.0
    excess_daily = daily - annual_risk_free_rate / 252
    sharpe = (
        float(excess_daily.mean() / excess_daily.std(ddof=1) * np.sqrt(252))
        if len(excess_daily) > 1 and excess_daily.std(ddof=1) > 0
        else 0.0
    )
    downside = excess_daily[excess_daily < 0]
    sortino = (
        float(excess_daily.mean() / downside.std(ddof=1) * np.sqrt(252))
        if len(downside) > 1 and downside.std(ddof=1) > 0
        else 0.0
    )

    returns = pd.Series([row["return_pct"] / 100 for row in trade_rows], dtype=float)
    wins = returns[returns > 0]
    losses = returns[returns <= 0]
    gross_profit = float(wins.sum())
    gross_loss = abs(float(losses.sum()))
    profit_factor = gross_profit / gross_loss if gross_loss > 0 else (float("inf") if gross_profit > 0 else 0.0)

    return {
        "starting_equity": float(equity.iloc[0]),
        "ending_equity": float(equity.iloc[-1]),
        "total_return": float(total_return),
        "cagr": float(cagr),
        "annual_volatility": volatility,
        "sharpe_ratio": sharpe,
        "sortino_ratio": sortino,
        "max_drawdown": max_drawdown(equity),
        "trades": int(len(returns)),
        "win_rate": float((returns > 0).mean()) if len(returns) else 0.0,
        "profit_factor": float(profit_factor),
        "average_trade": float(returns.mean()) if len(returns) else 0.0,
    }
