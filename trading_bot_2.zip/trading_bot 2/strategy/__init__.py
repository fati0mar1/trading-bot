"""Reusable signal, indicator, risk, cost, and performance modules."""
