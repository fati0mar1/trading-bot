"""Position-sizing helpers used by the simulator."""

import math

from config import RiskConfig


def stop_distance(entry_price: float, atr_value: float, risk: RiskConfig) -> float:
    """Clamp an ATR stop so it cannot be implausibly tight or extremely wide."""
    raw = atr_value * risk.atr_stop_multiplier
    minimum = entry_price * risk.min_stop_pct
    maximum = entry_price * risk.max_stop_pct
    return min(max(raw, minimum), maximum)


def position_size(
    *,
    equity: float,
    cash: float,
    entry_price: float,
    distance_to_stop: float,
    current_exposure: float,
    risk: RiskConfig,
    entry_fee_rate: float = 0.0,
) -> int:
    """Return whole shares allowed by every risk and cash limit."""
    if min(equity, cash, entry_price, distance_to_stop) <= 0:
        return 0
    by_trade_risk = math.floor((equity * risk.risk_per_trade) / distance_to_stop)
    by_position = math.floor((equity * risk.max_position_pct) / entry_price)
    remaining_exposure = max(
        0.0, equity * risk.max_portfolio_exposure - current_exposure
    )
    by_exposure = math.floor(remaining_exposure / entry_price)
    by_cash = math.floor(cash / (entry_price * (1 + entry_fee_rate)))
    return max(0, min(by_trade_risk, by_position, by_exposure, by_cash))
