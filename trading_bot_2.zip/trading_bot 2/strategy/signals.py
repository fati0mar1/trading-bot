"""Signal construction for completed daily candles.

The signal is decided after day t closes and can only be traded at day t+1's
open. The breakout level is shifted by one day so today's high never helps set
the threshold that today's close is trying to break.
"""

import pandas as pd

from strategy.indicators import atr, ema, rsi, sma, volume_ratio
from strategy.parameters import StrategyParams


def build_features(data: pd.DataFrame, params: StrategyParams) -> pd.DataFrame:
    required = {"Open", "High", "Low", "Close", "Volume"}
    missing = required.difference(data.columns)
    if missing:
        raise ValueError(f"missing OHLCV columns: {sorted(missing)}")

    result = data.copy().sort_index()
    result["EMA_FAST"] = ema(result["Close"], params.ema_fast)
    result["EMA_SLOW"] = ema(result["Close"], params.ema_slow)
    result["REGIME_SMA"] = sma(result["Close"], params.regime_sma)
    result["RSI"] = rsi(result["Close"], params.rsi_period)
    result["ATR"] = atr(result, params.atr_period)
    result["ATR_PCT"] = result["ATR"] / result["Close"]
    result["VOLUME_RATIO"] = volume_ratio(result["Volume"], params.volume_window)
    result["BREAKOUT_LEVEL"] = (
        result["High"].shift(1).rolling(params.breakout_window).max()
    )

    trend = (
        (result["Close"] > result["REGIME_SMA"])
        & (result["EMA_FAST"] > result["EMA_SLOW"])
    )
    momentum = result["RSI"].between(
        params.rsi_low, params.rsi_high, inclusive="both"
    )
    confirmed_breakout = result["Close"] > result["BREAKOUT_LEVEL"]
    liquid_move = result["VOLUME_RATIO"] >= params.volume_multiplier
    controlled_volatility = result["ATR_PCT"].between(
        params.min_atr_pct, params.max_atr_pct, inclusive="both"
    )

    result["RAW_SIGNAL"] = (
        trend & momentum & confirmed_breakout & liquid_move & controlled_volatility
    ).fillna(False)

    # Only the first day of a run is an entry. This prevents repeated entries
    # from a single multi-day breakout condition.
    result["ENTRY_SIGNAL"] = (
        result["RAW_SIGNAL"] & ~result["RAW_SIGNAL"].shift(1, fill_value=False)
    )

    # A deterministic strength score removes ticker-order bias when more
    # candidates appear than the portfolio can accept.
    breakout_strength = (result["Close"] / result["BREAKOUT_LEVEL"] - 1).clip(0, 0.20)
    volume_strength = (result["VOLUME_RATIO"] - params.volume_multiplier).clip(0, 5)
    trend_strength = (result["EMA_FAST"] / result["EMA_SLOW"] - 1).clip(0, 0.20)
    result["SIGNAL_SCORE"] = (
        breakout_strength * 100 + volume_strength + trend_strength * 50
    ).fillna(0.0)
    return result


def market_regime(benchmark: pd.DataFrame) -> pd.Series:
    """True when SPY is above its 200-day average and its 20 EMA > 50 EMA."""
    close = benchmark["Close"].astype(float)
    return ((close > sma(close, 200)) & (ema(close, 20) > ema(close, 50))).fillna(False)
