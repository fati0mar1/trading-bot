"""Execution boundary for a future broker connection.

Only DryRunExecution is implemented. A future broker-specific adapter must
implement the same small interface and pass dedicated paper-account tests
before it can be considered for live use.
"""

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import json
from pathlib import Path
from typing import Literal, Protocol
from uuid import uuid4


@dataclass(frozen=True)
class OrderRequest:
    symbol: str
    side: Literal["BUY", "SELL"]
    quantity: int
    reason: str

    def __post_init__(self) -> None:
        if not self.symbol.strip():
            raise ValueError("symbol cannot be empty")
        if self.side not in {"BUY", "SELL"}:
            raise ValueError("side must be BUY or SELL")
        if self.quantity < 1:
            raise ValueError("quantity must be at least 1")


@dataclass(frozen=True)
class OrderReceipt:
    order_id: str
    status: str
    recorded_at_utc: str


class ExecutionAdapter(Protocol):
    """Contract a future paper/live broker adapter must satisfy."""

    def submit(self, order: OrderRequest) -> OrderReceipt: ...

    def cancel_all(self) -> None: ...


class DryRunExecution:
    """Record an intended order locally without contacting any broker."""

    def __init__(self, ledger_path: str | Path = "results/dry_run_orders.jsonl") -> None:
        self.ledger_path = Path(ledger_path)

    def submit(self, order: OrderRequest) -> OrderReceipt:
        receipt = OrderReceipt(
            order_id=f"dry-{uuid4()}",
            status="RECORDED_NOT_SENT",
            recorded_at_utc=datetime.now(timezone.utc).isoformat(),
        )
        self.ledger_path.parent.mkdir(parents=True, exist_ok=True)
        record = {"order": asdict(order), "receipt": asdict(receipt)}
        with self.ledger_path.open("a", encoding="utf-8") as ledger:
            ledger.write(json.dumps(record) + "\n")
        return receipt

    def cancel_all(self) -> None:
        # There are no external orders to cancel in dry-run mode.
        return None
