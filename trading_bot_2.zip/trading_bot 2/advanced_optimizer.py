"""Compatibility entry point for the larger, slower optimizer grid."""

from optimizer import run_optimizer


if __name__ == "__main__":
    run_optimizer(expanded=True, output_directory="results/advanced_optimizer")
