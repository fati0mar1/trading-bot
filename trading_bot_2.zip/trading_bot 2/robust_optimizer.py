"""Compatibility entry point for the conservative walk-forward optimizer."""

from optimizer import run_optimizer


if __name__ == "__main__":
    run_optimizer(expanded=False, output_directory="results/robust_optimizer")
