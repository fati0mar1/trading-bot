# Paper Trading Bot — upgraded existing project

This is the revised version of the original `trading_bot` project. It keeps the
same familiar entry points while fixing the largest timing, risk, cost, and
testing problems. It cannot submit a broker order.

## What each file does

- `main.py` — the simplest starting point. With no arguments it runs a safe historical paper simulation.
- `scanner.py` — ranks stocks using the latest fully completed daily candle.
- `backtest.py` — downloads data and reports portfolio-level performance.
- `portfolio_simulator.py` — walks through every trading day in chronological order, opens positions, checks stops, charges costs, and updates cash.
- `execution.py` — a broker-neutral interface plus a dry-run recorder that cannot send an order.
- `optimizer.py` — checks a small parameter grid on chronological validation windows and reserves the final 20% as an untouched test.
- `robust_optimizer.py` — shortcut for the conservative optimizer.
- `advanced_optimizer.py` — shortcut for a larger, slower grid.
- `risk_test.py` — compares different per-trade risk settings.
- `stress_test.py` — checks whether results survive higher trading friction.
- `strategy/` — reusable indicators, signals, sizing, costs, parameters, and metrics.
- `CLAUDE.md` — safety and timing rules Claude should preserve when helping edit the project.

## Strategy in plain English

The strategy looks for a stock that is already in an uptrend, closes above its
previous breakout level, has reasonable RSI and volatility, and has confirming
volume. The signal is formed only after the daily candle closes. A simulated
purchase can therefore happen no earlier than the next day's opening price.

The portfolio risks 0.5% of equity to the initial stop on one trade, caps a
single position at 20%, caps total exposure at 80%, permits at most five open
positions, and stops adding risk if a daily-loss or drawdown circuit breaker is
hit. Overnight gaps can still lose more than the planned amount; no stop can
guarantee its price through a gap.

## Install

Python 3.11 or 3.12 is recommended.

### macOS or Linux

```bash
cd trading_bot
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m unittest discover -s tests -v
```

### Windows PowerShell

```powershell
cd trading_bot
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m unittest discover -s tests -v
```

## Run

Safe default paper backtest:

```bash
python main.py
```

Scan completed daily bars:

```bash
python main.py scan --tickers AAPL MSFT NVDA AMZN META
```

Choose a historical period and save CSV output:

```bash
python main.py backtest --start 2018-01-01 --results results
```

Run the conservative optimizer:

```bash
python main.py optimize --start 2015-01-01
```

Run the larger grid only after the conservative workflow works:

```bash
python main.py optimize --start 2015-01-01 --expanded-grid
```

## Important limitations

- Historical success does not guarantee future profit.
- `yfinance` is used for learning and research, not as a live execution feed.
- Daily bars cannot reproduce the exact intraday order of every price movement.
- Stops can fill worse than planned during overnight gaps.
- The current stock list is not a point-in-time historical universe, so selection and survivorship bias remain possible.
- Do not add a broker until the strategy has passed repeated paper testing with frozen parameters.

## Eventual path to real trading

The project now has an execution boundary in `execution.py`. When a broker is
chosen, a separate adapter can implement that interface without putting broker
code inside the signal or backtest modules. A responsible progression is:

1. Freeze a strategy version and reproduce its historical results.
2. Run the same logic in the broker's official paper account for several market regimes.
3. Reconcile every intended order, broker fill, fee, rejection, and position daily.
4. Test stale data, rejected orders, partial fills, disconnects, restarts, and the kill switch.
5. Require human approval before enabling any live adapter.
6. If live use is later approved, begin with separately capped capital and preserve the ability to disable new orders immediately.

No date or backtest result by itself makes the bot “ready”; operational paper
results and failure handling matter just as much as strategy statistics.
