"""Stress the strategy with increasingly unfavorable trading costs."""

import pandas as pd

from config import BENCHMARK_TICKER, DEFAULT_TICKERS, CostConfig
from data import default_start, download_daily_bars, download_universe
from portfolio_simulator import simulate_portfolio


def main() -> None:
    start = default_start(10)
    market, errors = download_universe(DEFAULT_TICKERS, start)
    if errors:
        print("Skipped symbols:", errors)
    benchmark = download_daily_bars(BENCHMARK_TICKER, start)
    scenarios = (
        ("baseline", CostConfig(slippage_bps=10, commission_bps=1)),
        ("double_friction", CostConfig(slippage_bps=20, commission_bps=2)),
        ("severe_friction", CostConfig(slippage_bps=50, commission_bps=5)),
    )
    rows = []
    for name, costs in scenarios:
        result = simulate_portfolio(market, benchmark_data=benchmark, costs=costs)
        rows.append(
            {
                "scenario": name,
                "slippage_bps_each_way": costs.slippage_bps,
                "commission_bps_each_way": costs.commission_bps,
                **result.metrics,
            }
        )
    report = pd.DataFrame(rows)
    print("\n===== TRADING-FRICTION STRESS TEST =====")
    print(report.to_string(index=False))
    report.to_csv("stress_test_results.csv", index=False)


if __name__ == "__main__":
    main()
