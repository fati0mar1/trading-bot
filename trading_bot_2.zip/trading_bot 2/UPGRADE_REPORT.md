# Upgrade report

## Outcome

The original project has been converted from several disconnected signal and
return scripts into one shared, chronological paper portfolio engine. The
strategy remains long-only and daily-bar based, using trend, RSI, volume, ATR,
and breakout information. Historical performance is not guaranteed and has not
been independently established by this code review.

## Code review and repairs

- All Python files compile under the validated environment.
- Imports are centralized and no production module imports a broker SDK.
- `requirements.txt` and `pyproject.toml` replace the archived virtual environment.
- Data is validated for required OHLCV fields, ordering, duplicates, numeric values, and positive prices.
- Network errors on one ticker no longer terminate the entire scan or backtest.
- Today's possibly unfinished daily candle is excluded by using an exclusive end date.
- The scanner's repeated nested ranking output is removed.
- Parameter dataclasses now reject impossible windows, thresholds, negative costs, and invalid risk limits.

## Strategy changes

- Preserved the original EMA, RSI, and volume concepts.
- Added a 200-day trend filter.
- Added a breakout above the previous rolling high; the breakout threshold is shifted one day to prevent look-ahead.
- Added reasonable ATR-percentage bounds to avoid unusually quiet or chaotic conditions.
- Emits only the first signal in a continuous signal run.
- Ranks simultaneous candidates by a deterministic strength score rather than ticker-list order.
- Optional SPY regime confirmation is enabled by default.

These are noise filters, not a claim that the strategy will be profitable.

## Execution and risk changes

- Signal at day `t` close enters no earlier than day `t+1` open.
- Entry sizing uses ATR from the prior completed signal bar.
- Entry-day stops are processed after the entry.
- Overnight gaps receive the worse opening fill when they jump through a stop.
- The entry day counts as holding day one.
- Initial and trailing ATR stops are implemented; a trailing stop calculated at today's close becomes effective next session.
- Risk per trade, one-position limit, total exposure, open-position count, maximum drawdown, and daily loss are all enforced.
- Slippage and commission change cash, P&L, equity, and metrics at the time of every fill.
- Circuit-breaker liquidation occurs at the next available open instead of pretending to trade a close after seeing it.
- `execution.py` provides a broker-neutral boundary and a dry-run recorder. No live adapter exists.

## Backtest and optimizer changes

- Performance is calculated from one chronological portfolio equity curve, not by compounding overlapping hypothetical trades.
- Metrics include total return, CAGR, annual volatility, Sharpe, Sortino, maximum drawdown, trades, win rate, profit factor, and average trade.
- The optimizer uses two non-overlapping chronological validation windows.
- The final 20% is kept out of parameter selection and evaluated once as a holdout.
- The default grid is intentionally small to reduce data-mining risk.
- Risk and higher-friction scenario scripts reuse the exact same simulator.

## Validation performed

The included standard-library test suite checks:

- paper-only safety flags;
- dry-run execution never sends an order;
- RSI edge cases;
- no future-row leakage in signal history;
- costs reduce returns;
- position size respects risk and concentration limits;
- equity-curve drawdown math;
- an entry-day stop is captured;
- daily-loss circuit breaker activation; and
- holding-period alignment.

Run it with:

```bash
python -m unittest discover -s tests -v
```

## Remaining limitations before real money

- Free research data is not a production trading feed.
- The current ticker list has survivorship and selection bias.
- Daily bars cannot reconstruct exact intraday price order.
- A point-in-time tradable universe and delisted securities are not included.
- The system has not yet been connected to an official broker paper account.
- Broker reconciliation, partial fills, rejected orders, exchange calendars, retry/idempotency logic, alerts, restart recovery, and an operator kill switch remain required.
- A sustained paper-trading record with frozen parameters is required before considering a live adapter.
