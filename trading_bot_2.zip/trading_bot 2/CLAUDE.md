# Claude project rules

This repository is intentionally **paper trading and historical simulation only**.

When editing it:

1. Never add or activate live broker order submission without explicit human review.
2. Keep `PAPER_MODE=True` and `LIVE_TRADING_AVAILABLE=False`.
3. A signal formed at day `t` close may enter no earlier than day `t+1` open.
4. Opening position size must use ATR from the previous completed bar, never the entry day's High/Low/Close.
5. Check entry-day stops after entry; do not skip the first day's Low.
6. Apply slippage and commissions to cash and equity, not only final reporting.
7. Keep risk configuration centralized in `config.py`.
8. Do not compound overlapping hypothetical trades outside the portfolio engine.
9. Do not weaken max position, exposure, drawdown, or daily-loss checks to improve a backtest.
10. Run `python -m unittest discover -s tests -v` after every strategy or simulator change.
11. Keep broker-specific code behind `ExecutionAdapter`; never import a broker SDK into signal, risk, backtest, or optimizer modules.

Any claim of improved performance must be supported by an untouched holdout period and clearly described as historical, not guaranteed.
