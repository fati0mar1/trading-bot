"""Compare several per-trade risk levels using the same portfolio engine."""

from dataclasses import replace

import pandas as pd

from config import BENCHMARK_TICKER, DEFAULT_TICKERS, RiskConfig
from data import default_start, download_daily_bars, download_universe
from portfolio_simulator import simulate_portfolio


def main() -> None:
    start = default_start(10)
    market, errors = download_universe(DEFAULT_TICKERS, start)
    if errors:
        print("Skipped symbols:", errors)
    benchmark = download_daily_bars(BENCHMARK_TICKER, start)
    base = RiskConfig()
    rows = []
    for name, risk_per_trade in (
        ("conservative", 0.0025),
        ("baseline", 0.0050),
        ("higher_risk", 0.0100),
    ):
        result = simulate_portfolio(
            market,
            benchmark_data=benchmark,
            risk=replace(base, risk_per_trade=risk_per_trade),
        )
        rows.append({"scenario": name, "risk_per_trade": risk_per_trade, **result.metrics})
    report = pd.DataFrame(rows)
    print("\n===== RISK COMPARISON (PAPER SIMULATION) =====")
    print(report.to_string(index=False))
    report.to_csv("risk_comparison.csv", index=False)


if __name__ == "__main__":
    main()
