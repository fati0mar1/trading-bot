# Pre-Registration — Next-Generation Research Architecture (Batch 0)

Status: **LOCKED specification for the redesign effort.** This document is Batch 0
of the approved redesign plan. It contains no code and changes no runtime
behavior. It is the commitment device that every later batch must obey.

Repository baseline this document is built on: commit `f9ce109` on `main`,
tagged `checkpoint-pre-redesign-batch0`. This document is authored on branch
`redesign-batch0-preregistration`, itself created from that commit.

This document uses two labels throughout:

- **LOCKED** — a rule or value that is fixed as of this commit. It may never be
  changed after any protected validation resource (defined below) has been
  viewed, for any reason, including a disappointing result.
- **UNRESOLVED — MUST BE SET BEFORE BATCH 1** — a parameter the approved
  redesign plan named as necessary but did not give a specific value for. No
  value is invented here. Each is listed in the registry in §14. Batch 1 may
  not begin until every item in that registry has a concrete value recorded
  in a dated edit to this document made **before** any new market data is
  downloaded or inspected. Once Batch 1 makes first contact with real data,
  this entire document — resolved and previously-unresolved sections alike —
  is frozen and may never be edited again.

---

## 1. Consumed evidence ledger — permanently retired

The following results are **consumed research evidence**. They were produced,
and then viewed, three separate times (initial reproduction, 2×/3× cost
stress, TSLA-exclusion sensitivity) across the prior sessions on this project.
Because they have been viewed, they can **never again** be treated as unseen
validation, for this hypothesis or any future one built on the same universe
and date range. No future strategy may be selected, tuned, gated, or reported
as validated using the 2024‑04‑18 → 2026‑08‑18 window on the ten-ticker
`DEFAULT_TICKERS` universe. This rule is **LOCKED** and unconditional.

Retired holdout window: `2024-04-18` → `2026-08-18` (the original optimizer's
final 20% holdout, universe = `config.DEFAULT_TICKERS`, start date
`2015-01-01`).

Consumed findings, permanently on record:

| Finding | Value |
|---|---|
| Original holdout total return | ≈ +1.51% |
| Original holdout ending equity | ≈ $10,151.15 (from $10,000 starting equity) |
| Completed trades | 60 |
| Win rate | 38.33% |
| Profit factor | ≈ 1.006 |
| Sharpe ratio | ≈ 0.19 |
| Maximum drawdown | ≈ −5.74% |
| SPY buy-and-hold, same window | ≈ +57.01% |
| Cost sensitivity | Performance weakened materially at 2× the baseline slippage/commission assumptions (profit factor fell below 1.0) |
| Ticker concentration | TSLA generated essentially all net profit; the strategy was not profitable without it |
| TSLA-excluded result | ≈ −0.21% total return (≈ −$21.41 ending P&L) |
| TSLA-excluded profit factor | ≈ 0.927 |
| Conclusion already reached | **No reliable edge was demonstrated.** This is the closed baseline the redesign starts from, not a strategy to rescue. |

**LOCKED rule**: no future document, gate, or report produced under this
redesign may re-open, re-run, or re-litigate the above window as if it were
still unseen. It may only be cited as historical, already-consumed evidence.

---

## 2. New research hypothesis

**UNRESOLVED — MUST BE SET BEFORE BATCH 1.** The redesign plan requires a
single, interpretable, economically motivated hypothesis with **no more than
three free parameters**, specified in writing before any data contact, and
never touched again once Batch 1 begins. No specific hypothesis was chosen in
the approved plan — only the constraint on its shape. Inventing one here would
violate the instruction not to fabricate an unresolved decision. The
hypothesis, its economic rationale, its ≤3 parameters (named, with type and
bounds), and its exact entry/exit rule in causal, next-bar-executable form
must be written into a dated revision of this section before Batch 1 opens any
new dataset. This section is otherwise **LOCKED** as a constraint:

- **LOCKED**: at most 3 free parameters, total, across the entire signal.
- **LOCKED**: the hypothesis must be statable in one sentence of economic
  reasoning (e.g. a momentum, mean-reversion, or event-driven mechanism) —
  not a composite of several indicators chosen because they backtested well.
- **LOCKED**: no machine-learning model, ensemble, or fitted weighting scheme
  of any kind is in scope for this redesign. That question is explicitly
  deferred past this entire research program, not merely past Batch 0.

---

## 3. Universe construction and eligibility

- **LOCKED**: the universe for every stage (training, validation, sealed
  holdout, forward paper trading) must be constructed **point-in-time** —
  membership as of date *t* is determined using only information that would
  have been knowable at *t*. Using today's constituent list as a stand-in for
  a historical universe, as the retired baseline did, is disqualifying for
  this redesign.
- **LOCKED**: a security's tradability ends on its point-in-time delisting,
  merger, or acquisition date. It is not silently dropped from history before
  that date, and it is not silently omitted from the universe construction
  because it later became untraded. A terminal return (realized delisting
  return where available, else a documented conservative assumption) must be
  applied on exit — never a simple removal from the sample.
- **LOCKED**: eligibility is decided by an as-of-date query against a security
  master keyed on a permanent identifier, not by ticker string matching
  (tickers get reused and renamed).
- **UNRESOLVED — MUST BE SET BEFORE BATCH 1**: the minimum liquidity floor
  (e.g. a minimum average-dollar-volume threshold) and minimum price floor
  used to exclude illiquid or non-investable names from the point-in-time
  eligible set.
- **UNRESOLVED — MUST BE SET BEFORE BATCH 1**: the source of point-in-time
  index/membership history used to build the security master (this is an
  external data dependency; `yfinance` alone cannot supply it).

---

## 4. Data sources, price adjustment, survivorship handling, trading calendar

- **LOCKED**: prices used for signal construction and simulated fills must be
  split-and-dividend adjusted, using one documented adjustment methodology
  applied consistently across the entire universe and every stage.
- **LOCKED**: delisted securities must be included in the historical universe
  for the periods during which they were tradable (see §3). A dataset that
  only contains securities that survived to the present day is disqualifying
  for any validation or holdout stage under this redesign.
- **LOCKED**: any date/ticker combination with missing, restated, or
  vendor-flagged-unreliable data is excluded from that day's candidate list
  and logged. It is never silently forward-filled or interpolated.
- **LOCKED**: the trading calendar is the standard US equity exchange
  calendar; a signal formed at day *t* close may enter no earlier than day
  *t+1* open, unchanged from the existing project rule (`CLAUDE.md` rule 3).
- **UNRESOLVED — MUST BE SET BEFORE BATCH 1**: the specific data vendor(s)
  providing (a) point-in-time membership, (b) delisted-security price and
  corporate-action history, and (c) the risk-free / idle-cash yield series
  (§9). `yfinance`, used previously, is confirmed insufficient on its own for
  (a) and (b).

---

## 5. Stages: training, validation, final sealed holdout, forward paper trading

- **LOCKED, structural**: four stages, strictly ordered and non-reusable in
  the reverse direction:
  1. **Training / hypothesis specification** — no historical performance
     figures are computed. Used only to write §2.
  2. **Validation** — purged, embargoed walk-forward folds (§6) over history
     preceding the sealed holdout. May be viewed and iterated on. Nothing
     from this stage may leak into the sealed holdout or the forward
     paper-trading stage.
  3. **Final sealed holdout** — a single contiguous, most-recent slice of
     the point-in-time history, **never the retired 2024‑04‑18→2026‑08‑18
     window** (§1), computed **exactly once**, after every gate in §12 has
     already been evaluated and passed on the validation stage.
  4. **Forward paper trading** — a live-going-forward confirmation window,
     run only after the sealed holdout passes every gate. This is the only
     stage structurally immune to look-ahead, because it has not happened
     yet at the time it is defined.
- **UNRESOLVED — MUST BE SET BEFORE BATCH 1**: the exact calendar boundaries
  of the validation stage and the sealed holdout stage (dependent on the
  point-in-time history's actual start date, itself unresolved in §4), and
  the exact split proportions used to carve them (the retired baseline's
  45% / 62.5% / 80% cut points are not automatically reused — they applied to
  a different dataset and are not binding on the redesign).
- **LOCKED**: the sealed holdout's boundary dates, once set, are recorded in
  a dated revision of this document before Batch 1 touches any real data, and
  are never adjusted afterward regardless of what the sealed holdout result
  turns out to be.
- **UNRESOLVED — MUST BE SET BEFORE BATCH 1**: the forward paper-trading
  window length. The approved plan specified a range (6–12 months) without
  settling on one value; a single exact duration must be chosen and recorded
  before Batch 1, not decided adaptively once the window is underway.

---

## 6. One-way access rules for every protected validation resource

A "protected validation resource" is: the sealed holdout (§5.3), the
forward paper-trading result (§5.4), and the cross-sectional holdout (§10).

- **LOCKED**: each protected validation resource may be computed **at most
  once**. The code path that produces it must not be re-run with a different
  hypothesis, parameter value, ticker set, date range, cost assumption, or
  metric definition after it has been viewed.
- **LOCKED**: viewing constitutes contamination regardless of intent — an
  accidental print, log line, or partial read of a protected result
  contaminates it exactly as fully as a deliberate review.
- **LOCKED**: no protected validation resource may be computed until every
  applicable gate in §12 has already been passed on the validation stage
  (§5.2) using only pre-registered rules from this document.
- **LOCKED**: if a protected validation resource is contaminated (viewed
  under any circumstance before all its preconditions were met, or re-run
  after being viewed), it is permanently retired exactly as §1 retires the
  original holdout, and a new, never-before-touched date range or ticker
  partition must be defined to replace it before the redesign can continue.

---

## 7. Signal timing and execution assumptions

**LOCKED**, inherited unchanged from the existing, tested project rules
(`CLAUDE.md` rules 3–5, enforced in `portfolio_simulator.py` and covered by
`tests/test_core.py::test_signal_has_no_future_leak` and
`test_entry_day_stop_is_processed` in the committed baseline):

- A signal formed using day *t*'s completed close may enter no earlier than
  day *t+1*'s open.
- Every indicator used in signal construction must be strictly causal
  (rolling/EWM windows and any breakout/reference level use only data
  available at or before the bar being evaluated).
- Position sizing at entry uses ATR from the previous completed bar only,
  never the entry day's High/Low/Close.
- Entry-day stops are checked after entry, using the entry day's actual Low —
  the first day's stop risk is never skipped.
- A stop that gaps through its trigger price fills at the worse of the
  day's open or the stop price, never at the theoretical stop price itself.

Any new signal module (Batch 11 of the approved plan) must be unit-tested
for causality before it is ever run against real historical data, mirroring
the existing `test_signal_has_no_future_leak` pattern.

---

## 8. Position sizing, stops, portfolio limits, risk controls

**LOCKED**: inherited unchanged from the currently committed `RiskConfig` in
`config.py` (commit `f9ce109`):

| Parameter | Value |
|---|---|
| `initial_cash` | $10,000 |
| `risk_per_trade` | 0.5% of equity |
| `max_position_pct` | 20% of equity |
| `max_portfolio_exposure` | 80% of equity |
| `max_open_positions` | 5 |
| `max_drawdown` (circuit breaker) | 20% |
| `max_daily_loss` (circuit breaker) | 3% |
| `atr_stop_multiplier` | 2.0 |
| `trailing_atr_multiplier` | 3.0 |
| `min_stop_pct` / `max_stop_pct` | 1% / 8% |
| `max_holding_days` | 20 |

Any change to any of these values is itself a parameter change, is subject to
the same ≤3-free-parameter cap as the signal (§2) if it is proposed as part of
the new hypothesis, and is subject to the same one-way lock as every other
pre-registered value: it may be set only before Batch 1's first contact with
real data, and never adjusted afterward in response to a result.

---

## 9. Transaction costs and required 1×, 2×, 3× cost tests

- **LOCKED**: the baseline cost model is symmetric slippage plus commission,
  applied on both entry and exit, deducted from cash and equity at trade
  time (not only in final reporting) — unchanged mechanism from
  `strategy/costs.py`.
- **LOCKED**: exactly as done for the retired baseline, every reported
  validation-stage and sealed-holdout result must be computed at **1×, 2×,
  and 3×** the baseline slippage-and-commission assumption, with nothing else
  changed between the three runs. All three multiples must be reported
  together; the 1× result alone is never sufficient to claim an edge exists.
- **LOCKED**: if the more realistic liquidity/participation-cap cost model
  (ADV-scaled impact, partial fills — Batch 5 of the approved plan) is built
  and adopted before Batch 1's first real data run, it becomes the 1×
  baseline in place of the flat-bps model, and the 2×/3× stress multiples
  apply to it in the same way.
- **UNRESOLVED — MUST BE SET BEFORE BATCH 1**: the exact ADV participation
  cap percentage used by the realistic liquidity model, if that model is
  adopted before Batch 1 begins.

---

## 10. Benchmarks: cash, SPY, equal-weight, sector, exposure/vol-matched

- **LOCKED**: SPY buy-and-hold is computed over the identical stage dates as
  the strategy, using the identical starting capital, entering at the first
  in-window trading day's open and marking to close through the last
  in-window trading day, using the same adjusted-price convention as §4.
- **LOCKED**: cash is computed with the strategy's own starting capital and
  is never assumed to be a flat 0% return — see idle-cash yield below.
- **CONDITIONALLY LOCKED**: an equal-weight buy-and-hold of the same universe
  is a valid benchmark **only when** that universe was itself constructed
  point-in-time per §3. An equal-weight benchmark built from a fixed,
  present-day ticker list is disqualified by the same survivorship-bias rule
  that disqualified the retired baseline's universe, and must not be
  presented as a benchmark under this redesign.
- **LOCKED, mechanism**: an exposure-matched benchmark (SPY scaled to the
  strategy's realized average exposure) and a volatility-matched benchmark
  (SPY position sized to match the strategy's realized annualized volatility)
  must both be computed for every protected validation resource. Benchmark-
  relative performance (excess return over the volatility-matched benchmark)
  is the **primary** score, not any absolute return figure (§11).
- **UNRESOLVED — MUST BE SET BEFORE BATCH 1**: the sector benchmark ETF
  ticker(s) to use; the idle-cash / risk-free yield series and its data
  source; the numeric tolerance band within which an exposure- or
  volatility-matched benchmark is considered "matched."

---

## 11. Primary and secondary performance metrics

- **LOCKED — primary metric**: excess return over the volatility-matched
  benchmark (information ratio), computed identically for every validation
  fold and for the sealed holdout. Parameter/hypothesis selection, if any
  further selection ever occurs within the ≤3-parameter bound, must be driven
  by this metric, never by absolute Sharpe, absolute CAGR, or absolute
  return alone — this directly replaces the retired optimizer's
  benchmark-blind scoring formula.
- **LOCKED — secondary metrics**, always reported alongside the primary
  metric, never in place of it: total return, CAGR, annualized volatility,
  Sharpe ratio, Sortino ratio, maximum drawdown, win rate, profit factor
  computed **both** ways (percentage-return-weighted and dollar-weighted —
  the retired baseline showed these can disagree materially: 1.006 vs. 1.09),
  average trade, median trade, exposure (% of days with an open position,
  average exposure as % of equity), and turnover (total notional traded /
  average equity).
- **LOCKED**: every metric is reported for the strategy and for every
  benchmark in §10 side by side. A metric is never reported for the strategy
  alone.

---

## 12. Confidence intervals, multiple-testing controls, minimum sample size

- **LOCKED, method**: confidence intervals on Sharpe, CAGR, and excess return
  over the volatility-matched benchmark are computed with a block or
  stationary bootstrap that respects trade-level and cross-ticker
  autocorrelation. A naive i.i.d. resample of trades or daily returns is
  disqualifying — the retired baseline's trades overlap in calendar time
  across tickers and cannot be treated as independent draws.
- **LOCKED, method**: a deflated Sharpe ratio (or an equivalent explicit
  multiple-testing correction) must be computed, accounting for the total
  number of parameter/hypothesis configurations ever evaluated across this
  entire project — including the retired optimizer's 16-candidate grid — not
  just the configurations evaluated within the new redesign.
- **UNRESOLVED — MUST BE SET BEFORE BATCH 1**: the confidence level (e.g.
  95%) used for every interval in this section, the bootstrap block length
  and resample count, and the minimum total trade count and minimum
  per-ticker/per-year trade count required before any metric in §11 is
  considered statistically meaningful rather than descriptive.

---

## 13. Cross-ticker, cross-regime, concentration, turnover, and parameter-stability gates

- **LOCKED, mechanism**: for every protected validation resource, the exact
  diagnostic already performed manually on the retired baseline (per-ticker
  P&L contribution, per-year P&L contribution, single-largest-trade
  contribution, and re-simulation with the top contributor excluded) must be
  computed automatically and checked against a numeric cap (§14). This is not
  optional instrumentation — a result that has not passed this check has not
  been evaluated.
- **LOCKED, mechanism**: a static, pre-declared regime calendar (bull, bear,
  crash, recovery, sideways, high-volatility), labeled from independently
  documented market history and never fit to this project's own returns,
  must be used to confirm that no single regime accounts for materially more
  than its numeric cap (§14) of total profit.
- **LOCKED, mechanism**: a parameter-stability sweep over every neighboring
  value (±1 step in each free dimension, within the ≤3-parameter bound of §2)
  must be computed for every protected validation resource; an edge that
  exists only at one isolated parameter combination fails this gate by
  definition (§14).
- **LOCKED, mechanism**: turnover (§11) is reported and compared against a
  plausibility cap — a turnover figure inconsistent with the stated holding
  period or position limits indicates a modeling error and must be
  investigated as a defect (§15) before any performance conclusion is drawn.
- **UNRESOLVED — MUST BE SET BEFORE BATCH 1**: the exact regime-calendar
  date boundaries (dependent on the unresolved data-history start date, §4/
  §5), and every numeric cap referenced above — maximum permitted share of
  total profit attributable to one ticker, one trade, and one year/regime;
  minimum share of universe tickers required to show positive expectancy;
  and the pass/fail bound on the parameter-stability sweep.

---

## 14. Exact pass/fail criteria — registry

A protected validation resource **passes** only if every LOCKED mechanism in
§9–§13 is evaluated and every one of the following, once filled in, is
satisfied. Until every row below has a concrete value, **no protected
validation resource may be computed** — the gate is fail-closed, not
fail-open, in the absence of a number.

| # | Gate | Status |
|---|---|---|
| 1 | Minimum total completed trades | UNRESOLVED |
| 2 | Minimum share of universe tickers with positive expectancy | UNRESOLVED |
| 3 | Maximum share of total profit from one ticker | UNRESOLVED |
| 4 | Maximum share of total profit from one trade | UNRESOLVED |
| 5 | Maximum share of total profit from one year/regime | UNRESOLVED |
| 6 | Deflated-Sharpe / excess-return CI lower bound must exceed | UNRESOLVED (bound value); direction is LOCKED — the lower bound of the confidence interval, not the point estimate, must clear this bound |
| 7 | Profit factor at 3× cost stress must be at least | UNRESOLVED (value); LOCKED that both the %-weighted and $-weighted profit factor (§11) must each individually clear it |
| 8 | Parameter-stability sweep: fraction of ±1-step neighbors that must also pass gates 6–7 | UNRESOLVED |
| 9 | Cross-sectional holdout performance vs. tunable-set performance | UNRESOLVED (degradation tolerance); LOCKED that the comparison must use the same bootstrap CI method as gate 6 |
| 10 | Forward paper-trading result must satisfy | LOCKED — the same gates 1–9, recomputed on the forward window, with no exception |

**LOCKED, overriding rule**: failing **any** row above ends the hypothesis.
There is no partial pass, no case-by-case override, and no discretionary
judgment call that can substitute for a numeric gate once that gate's value
has been set.

---

## 15. Hypothesis-abandonment and forward-paper-trading failure conditions

**LOCKED.** The hypothesis is abandoned — not tuned, not partially rescued —
if any of the following occurs:

- Any row in §14 fails on the sealed holdout, and the failure is not
  attributable to a genuine, pre-documented implementation or data defect
  (§16).
- The parameter-stability sweep (§13, §14 row 8) shows the passing region is
  an isolated combination rather than a stable neighborhood.
- The cross-sectional holdout underperforms the tunable ticker set by more
  than its bootstrap confidence interval allows (§14 row 9) — evidence of
  overfitting to specific names, the exact failure mode that ended the
  retired baseline.
- The forward paper-trading window (§14 row 10) fails any gate that the
  sealed holdout passed.

Abandonment means: the hypothesis, exactly as pre-registered, is documented
as having shown no reliable edge, and filed alongside the retired baseline
(§1). It does **not** trigger a new indicator, a new ticker exclusion, a
parameter nudge, a metric substitution, or a new date range chosen after the
fact. Any of those responses to a failed gate is itself a violation of this
document.

---

## 16. Rescue-tuning prohibition and defect-handling rule

- **LOCKED**: no ticker, parameter, date range, gate value, metric
  definition, or exclusion rule may be changed, added, or removed after any
  protected validation resource (§6) has been viewed. This applies without
  exception, including when the change would be scientifically defensible in
  isolation — the act of viewing a protected result first is what disqualifies
  any subsequent change.
- **LOCKED**: a genuine implementation or data defect (a coding error, a
  data-vendor error, a unit conversion mistake, a lookahead bug) may be fixed
  only if it is documented — in writing, describing the defect and its
  mechanism — **before** any protected result affected by that code path has
  been viewed. If a defect is discovered only after a protected result has
  already been viewed, the defect does not entitle a re-run: that validation
  resource is retired under §6, exactly as if it had been contaminated by
  ordinary viewing, and a new, never-before-touched replacement resource must
  be defined before continuing.
- **LOCKED**: this rule applies retroactively to every UNRESOLVED item in
  this document — once a value is filled in and Batch 1 has made first
  contact with real data, no UNRESOLVED placeholder may be "resolved" or
  adjusted afterward, regardless of how the redesign is performing.

---

## 17. Reused vs. new architecture (context, not a gate)

For traceability only — this section does not itself create a gate.
Reusable as-is from the committed baseline (`f9ce109`): `strategy/indicators.py`,
`strategy/costs.py`, `strategy/risk.py`, the event-ordering core of
`portfolio_simulator.py`, `strategy/metrics.py`, `execution.py`'s
broker-neutral boundary, and `config.py`'s centralized-dataclass pattern.
Net-new modules required by this redesign (security master, data-vendor
abstraction, regime calendar, benchmark suite, realistic cost/liquidity
model, idle-cash yield, purged/embargoed splitter, cross-sectional holdout
sampler, statistics module, concentration-gate module) are none of them
implemented as of this document — implementing any of them is Batch 1 or
later, not Batch 0.

---

## 18. Unresolved-decision registry (consolidated)

Every item below must be resolved, in writing, in a dated revision of this
document, before Batch 1 makes first contact with any new market data. This
list is the single source of truth for what remains open; it is not
exhaustive of every word above, but every entry above tagged UNRESOLVED
appears here.

1. The new research hypothesis, its economic rationale, and its ≤3 named
   parameters with bounds (§2).
2. Minimum liquidity (ADV) and price floors for universe eligibility (§3).
3. Source of point-in-time index/membership history (§3).
4. Data vendor(s) for delisted-security history and idle-cash/risk-free
   yield series (§4).
5. Exact calendar boundaries and split proportions for the validation stage
   and the sealed holdout stage (§5).
6. Forward paper-trading window exact duration (§5).
7. ADV participation cap percentage, if the realistic liquidity cost model
   is adopted before Batch 1 (§9).
8. Sector benchmark ETF ticker(s); idle-cash yield source; exposure/
   volatility-match tolerance band (§10).
9. Confidence level, bootstrap block length and resample count, minimum
   total and per-ticker/per-year trade counts (§12).
10. Regime-calendar exact date boundaries (§13).
11. Numeric caps for §14 rows 1–9 (trade count, ticker/trade/year profit
    concentration, deflated-Sharpe/CI bound, 3×-cost profit-factor floor,
    parameter-stability pass fraction, cross-sectional degradation
    tolerance).

Until this registry is empty, Batch 1 does not begin.
