"""Chronological, paper-only portfolio simulator.

Daily event order is intentionally realistic:
1. Use yesterday's completed signal to enter at today's open.
2. Check today's low for a same-day or existing stop loss.
3. Apply time exits and update trailing stops at today's close.
4. Calculate closing equity and enforce portfolio circuit breakers.

There is no broker connection and no live-order code in this file.
"""

from dataclasses import dataclass
from typing import Mapping

import pandas as pd

from config import CostConfig, RiskConfig
from strategy.costs import buy_fill, commission, sell_fill
from strategy.metrics import calculate_metrics
from strategy.parameters import StrategyParams
from strategy.risk import position_size, stop_distance
from strategy.signals import build_features, market_regime


@dataclass
class Position:
    ticker: str
    signal_date: pd.Timestamp
    entry_date: pd.Timestamp
    entry_price: float
    shares: int
    entry_fee: float
    stop_price: float
    bars_held: int = 0


@dataclass
class Trade:
    ticker: str
    signal_date: pd.Timestamp
    entry_date: pd.Timestamp
    exit_date: pd.Timestamp
    entry_price: float
    exit_price: float
    shares: int
    entry_fee: float
    exit_fee: float
    pnl: float
    return_pct: float
    bars_held: int
    exit_reason: str


@dataclass
class SimulationResult:
    equity_curve: pd.DataFrame
    trades: pd.DataFrame
    metrics: dict[str, float | int]
    halted: bool
    halt_reason: str | None


def _validate_market_data(market_data: Mapping[str, pd.DataFrame]) -> None:
    if not market_data:
        raise ValueError("market_data cannot be empty")
    required = {"Open", "High", "Low", "Close", "Volume"}
    for ticker, frame in market_data.items():
        missing = required.difference(frame.columns)
        if missing:
            raise ValueError(f"{ticker} is missing columns: {sorted(missing)}")
        if frame.empty or not frame.index.is_monotonic_increasing:
            raise ValueError(f"{ticker} must contain sorted daily data")


def simulate_portfolio(
    market_data: Mapping[str, pd.DataFrame],
    *,
    benchmark_data: pd.DataFrame | None = None,
    strategy: StrategyParams | None = None,
    risk: RiskConfig | None = None,
    costs: CostConfig | None = None,
    trade_start: str | pd.Timestamp | None = None,
    trade_end: str | pd.Timestamp | None = None,
) -> SimulationResult:
    """Run an event-driven historical simulation with no live side effects."""
    _validate_market_data(market_data)
    strategy = strategy or StrategyParams()
    risk = risk or RiskConfig()
    costs = costs or CostConfig()

    frames = {ticker: data.copy().sort_index() for ticker, data in market_data.items()}
    features = {ticker: build_features(data, strategy) for ticker, data in frames.items()}
    regime = market_regime(benchmark_data.sort_index()) if benchmark_data is not None else None
    if strategy.require_market_regime and regime is None:
        raise ValueError("benchmark_data is required when require_market_regime=True")

    all_dates = sorted(set().union(*(frame.index for frame in frames.values())))
    start = pd.Timestamp(trade_start) if trade_start is not None else all_dates[0]
    end = pd.Timestamp(trade_end) if trade_end is not None else all_dates[-1]
    dates = [date for date in all_dates if start <= date <= end]
    if not dates:
        raise ValueError("no market dates exist inside the requested trade window")

    cash = float(risk.initial_cash)
    open_positions: dict[str, Position] = {}
    trade_log: list[Trade] = []
    equity_points = [
        {
            "date": dates[0] - pd.Timedelta(days=1),
            "equity": risk.initial_cash,
            "cash": risk.initial_cash,
            "exposure": 0.0,
        }
    ]
    previous_close_equity = float(risk.initial_cash)
    peak_equity = float(risk.initial_cash)
    halted = False
    halt_reason: str | None = None
    liquidate_next_open = False

    def price_as_of(ticker: str, date: pd.Timestamp, field: str) -> float:
        frame = frames[ticker]
        if date in frame.index:
            return float(frame.at[date, field])
        earlier = frame.loc[:date]
        if earlier.empty:
            return 0.0
        return float(earlier["Close"].iloc[-1])

    def portfolio_value(date: pd.Timestamp, field: str) -> tuple[float, float]:
        exposure = sum(
            position.shares * price_as_of(ticker, date, field)
            for ticker, position in open_positions.items()
        )
        return cash + exposure, exposure

    def close_position(
        ticker: str, date: pd.Timestamp, raw_price: float, reason: str
    ) -> None:
        nonlocal cash
        position = open_positions.pop(ticker)
        fill = sell_fill(raw_price, costs)
        gross_proceeds = position.shares * fill
        exit_fee = commission(gross_proceeds, costs)
        cash += gross_proceeds - exit_fee
        entry_total = position.shares * position.entry_price + position.entry_fee
        exit_total = gross_proceeds - exit_fee
        pnl = exit_total - entry_total
        trade_log.append(
            Trade(
                ticker=ticker,
                signal_date=position.signal_date,
                entry_date=position.entry_date,
                exit_date=date,
                entry_price=position.entry_price,
                exit_price=fill,
                shares=position.shares,
                entry_fee=position.entry_fee,
                exit_fee=exit_fee,
                pnl=pnl,
                return_pct=(pnl / entry_total) * 100,
                bars_held=position.bars_held,
                exit_reason=reason,
            )
        )

    def regime_allowed(signal_date: pd.Timestamp) -> bool:
        if not strategy.require_market_regime:
            return True
        history = regime.loc[:signal_date]  # type: ignore[union-attr]
        return bool(history.iloc[-1]) if not history.empty else False

    for current_date in dates:
        # A circuit breaker seen at yesterday's close is executed at today's
        # open. This avoids pretending we could trade yesterday's close after
        # seeing it.
        if liquidate_next_open:
            for ticker in list(open_positions):
                close_position(
                    ticker,
                    current_date,
                    price_as_of(ticker, current_date, "Open"),
                    halt_reason or "CIRCUIT_BREAKER",
                )
            liquidate_next_open = False

        # Build today's candidates from yesterday's completed rows.
        candidates: list[tuple[float, str, pd.Timestamp, float]] = []
        if not halted:
            for ticker, frame in frames.items():
                if ticker in open_positions or current_date not in frame.index:
                    continue
                location = frame.index.get_loc(current_date)
                if not isinstance(location, int) or location < 1:
                    continue
                previous = features[ticker].iloc[location - 1]
                signal_date = frame.index[location - 1]
                if bool(previous["ENTRY_SIGNAL"]) and regime_allowed(signal_date):
                    candidates.append(
                        (
                            float(previous["SIGNAL_SCORE"]),
                            ticker,
                            signal_date,
                            float(previous["ATR"]),
                        )
                    )

        # Highest-quality signals receive limited portfolio slots first.
        candidates.sort(key=lambda item: (-item[0], item[1]))
        for _, ticker, signal_date, prior_atr in candidates:
            if len(open_positions) >= risk.max_open_positions:
                break
            raw_open = float(frames[ticker].at[current_date, "Open"])
            entry_price = buy_fill(raw_open, costs)
            equity_open, current_exposure = portfolio_value(current_date, "Open")
            distance = stop_distance(entry_price, prior_atr, risk)
            shares = position_size(
                equity=equity_open,
                cash=cash,
                entry_price=entry_price,
                distance_to_stop=distance,
                current_exposure=current_exposure,
                risk=risk,
                entry_fee_rate=costs.commission_bps / 10_000,
            )
            if shares <= 0:
                continue
            notional = shares * entry_price
            entry_fee = commission(notional, costs)
            if notional + entry_fee > cash:
                continue
            cash -= notional + entry_fee
            open_positions[ticker] = Position(
                ticker=ticker,
                signal_date=signal_date,
                entry_date=current_date,
                entry_price=entry_price,
                shares=shares,
                entry_fee=entry_fee,
                stop_price=entry_price - distance,
            )

        # Stops are checked after the opening orders, so an entry-day stop is
        # not missed. A gap below the stop fills at the worse opening price.
        for ticker in list(open_positions):
            frame = frames[ticker]
            if current_date not in frame.index:
                continue
            position = open_positions[ticker]
            day_open = float(frame.at[current_date, "Open"])
            day_low = float(frame.at[current_date, "Low"])
            if day_low <= position.stop_price:
                raw_stop_fill = min(day_open, position.stop_price)
                close_position(ticker, current_date, raw_stop_fill, "HARD_STOP")

        # One completed trading session is counted on the entry day. This
        # keeps a 20-day hold aligned with open(day 1) -> close(day 20).
        for ticker in list(open_positions):
            frame = frames[ticker]
            if current_date not in frame.index:
                continue
            position = open_positions[ticker]
            position.bars_held += 1
            close_price = float(frame.at[current_date, "Close"])
            if position.bars_held >= risk.max_holding_days:
                close_position(ticker, current_date, close_price, "TIME_EXIT")
                continue
            current_atr = float(features[ticker].at[current_date, "ATR"])
            if pd.notna(current_atr) and current_atr > 0:
                # This new stop becomes effective on the next session because
                # today's close and ATR are only known after today has ended.
                trailing_stop = close_price - risk.trailing_atr_multiplier * current_atr
                position.stop_price = max(position.stop_price, trailing_stop)

        # Close residual positions at the declared end of a backtest so trade
        # statistics and cash agree. This is an evaluation boundary, not a
        # live-trading instruction.
        if current_date == dates[-1]:
            for ticker in list(open_positions):
                close_position(
                    ticker,
                    current_date,
                    price_as_of(ticker, current_date, "Close"),
                    "END_OF_TEST",
                )

        closing_equity, closing_exposure = portfolio_value(current_date, "Close")
        peak_equity = max(peak_equity, closing_equity)
        drawdown = closing_equity / peak_equity - 1
        daily_return = closing_equity / previous_close_equity - 1
        equity_points.append(
            {
                "date": current_date,
                "equity": closing_equity,
                "cash": cash,
                "exposure": closing_exposure,
            }
        )

        if not halted and drawdown <= -risk.max_drawdown:
            halted = True
            halt_reason = "MAX_DRAWDOWN"
            liquidate_next_open = bool(open_positions)
        elif not halted and daily_return <= -risk.max_daily_loss:
            halted = True
            halt_reason = "MAX_DAILY_LOSS"
            liquidate_next_open = bool(open_positions)
        previous_close_equity = closing_equity

    equity_curve = pd.DataFrame(equity_points).set_index("date")
    trades = pd.DataFrame([trade.__dict__ for trade in trade_log])
    metrics = calculate_metrics(equity_curve["equity"], trade_log)
    return SimulationResult(
        equity_curve=equity_curve,
        trades=trades,
        metrics=metrics,
        halted=halted,
        halt_reason=halt_reason,
    )
