"""Rank stocks using the latest fully completed daily candle."""

from typing import Iterable

import pandas as pd

from data import default_start, download_universe
from strategy.parameters import StrategyParams
from strategy.signals import build_features


def scan_market(
    tickers: Iterable[str],
    *,
    start: str | None = None,
    end: str | None = None,
    params: StrategyParams | None = None,
) -> pd.DataFrame:
    params = params or StrategyParams()
    market, errors = download_universe(tickers, start or default_start(3), end)
    rows: list[dict[str, object]] = []
    for ticker, data in market.items():
        features = build_features(data, params)
        latest = features.iloc[-1]
        rows.append(
            {
                "ticker": ticker,
                "bar_date": features.index[-1].date().isoformat(),
                "close": float(latest["Close"]),
                "entry_signal": bool(latest["ENTRY_SIGNAL"]),
                "signal_score": float(latest["SIGNAL_SCORE"]),
                "rsi": float(latest["RSI"]),
                "volume_ratio": float(latest["VOLUME_RATIO"]),
                "atr_pct": float(latest["ATR_PCT"]),
                "trend": "UP" if latest["EMA_FAST"] > latest["EMA_SLOW"] else "DOWN",
                "above_200_sma": bool(latest["Close"] > latest["REGIME_SMA"]),
            }
        )
    for ticker, message in errors.items():
        print(f"Skipped {ticker}: {message}")
    if not rows:
        return pd.DataFrame()
    return pd.DataFrame(rows).sort_values(
        ["entry_signal", "signal_score"], ascending=[False, False]
    ).reset_index(drop=True)


def print_scan(results: pd.DataFrame) -> None:
    if results.empty:
        print("No valid scan results.")
        return
    display = results.copy()
    display["close"] = display["close"].map(lambda value: f"${value:,.2f}")
    for column in ("signal_score", "rsi", "volume_ratio"):
        display[column] = display[column].map(lambda value: f"{value:.2f}")
    display["atr_pct"] = display["atr_pct"].map(lambda value: f"{value * 100:.2f}%")
    print("\n===== COMPLETED-BAR STOCK SCANNER =====")
    print(display.to_string(index=False))
