"""Market-data loading and validation.

yfinance is suitable for learning and research. It is not used as a live
execution feed in this project.
"""

from datetime import date, timedelta
from typing import Iterable

import pandas as pd


REQUIRED_COLUMNS = ["Open", "High", "Low", "Close", "Volume"]


def clean_ohlcv(data: pd.DataFrame, ticker: str = "unknown") -> pd.DataFrame:
    if data is None or data.empty:
        raise ValueError(f"no data returned for {ticker}")
    missing = set(REQUIRED_COLUMNS).difference(data.columns)
    if missing:
        raise ValueError(f"{ticker} is missing columns: {sorted(missing)}")
    result = data[REQUIRED_COLUMNS].copy()
    result.index = pd.DatetimeIndex(result.index).tz_localize(None)
    result = result[~result.index.duplicated(keep="last")].sort_index()
    result = result.apply(pd.to_numeric, errors="coerce").dropna()
    result = result[
        (result["Open"] > 0)
        & (result["High"] > 0)
        & (result["Low"] > 0)
        & (result["Close"] > 0)
        & (result["Volume"] >= 0)
    ]
    if result.empty:
        raise ValueError(f"{ticker} has no valid OHLCV rows")
    return result


def completed_bar_end() -> str:
    """Exclusive end date that avoids using today's unfinished daily candle."""
    return date.today().isoformat()


def download_daily_bars(
    ticker: str,
    start: str,
    end: str | None = None,
) -> pd.DataFrame:
    try:
        import yfinance as yf
    except ImportError as error:
        raise RuntimeError("Install dependencies with: pip install -r requirements.txt") from error

    end = end or completed_bar_end()
    data = yf.download(
        ticker,
        start=start,
        end=end,
        interval="1d",
        auto_adjust=True,
        multi_level_index=False,
        progress=False,
        threads=False,
    )
    return clean_ohlcv(data, ticker)


def download_universe(
    tickers: Iterable[str], start: str, end: str | None = None
) -> tuple[dict[str, pd.DataFrame], dict[str, str]]:
    market: dict[str, pd.DataFrame] = {}
    errors: dict[str, str] = {}
    for ticker in dict.fromkeys(t.upper().strip() for t in tickers if t.strip()):
        try:
            market[ticker] = download_daily_bars(ticker, start, end)
        except Exception as error:  # one bad symbol should not crash every symbol
            errors[ticker] = str(error)
    return market, errors


def default_start(years: int = 8) -> str:
    return (date.today() - timedelta(days=365 * years + years // 4)).isoformat()
