"""Small walk-forward parameter search with a final untouched holdout period.

The optimizer downloads data once, evaluates candidates on two chronological
validation windows, chooses one candidate without looking at the final 20%,
and reports that final period exactly once. More combinations are not
automatically better; a small grid reduces data-mining risk.
"""

from dataclasses import asdict, replace
from itertools import product
from pathlib import Path
from statistics import median
from typing import Iterable, Sequence

import pandas as pd

from config import BENCHMARK_TICKER, DEFAULT_TICKERS, CostConfig, RiskConfig
from data import default_start, download_daily_bars, download_universe
from portfolio_simulator import SimulationResult, simulate_portfolio
from strategy.parameters import StrategyParams


def conservative_grid(base: StrategyParams | None = None) -> list[StrategyParams]:
    base = base or StrategyParams()
    return [
        replace(
            base,
            ema_fast=fast,
            ema_slow=slow,
            breakout_window=breakout,
            volume_multiplier=volume,
        )
        for fast, slow, breakout, volume in product(
            (10, 20), (50, 100), (20, 55), (1.0, 1.25)
        )
        if fast < slow
    ]


def expanded_grid(base: StrategyParams | None = None) -> list[StrategyParams]:
    base = base or StrategyParams()
    return [
        replace(
            base,
            ema_fast=fast,
            ema_slow=slow,
            breakout_window=breakout,
            volume_multiplier=volume,
            rsi_high=rsi_high,
        )
        for fast, slow, breakout, volume, rsi_high in product(
            (10, 20, 30), (50, 100, 150), (20, 40, 55), (1.0, 1.25), (68.0, 75.0)
        )
        if fast < slow
    ]


def _score(metrics: Sequence[dict[str, float | int]]) -> float:
    total_trades = sum(int(item["trades"]) for item in metrics)
    if total_trades < 20:
        return float("-inf")
    med_sharpe = median(float(item["sharpe_ratio"]) for item in metrics)
    med_cagr = median(float(item["cagr"]) for item in metrics)
    worst_drawdown = min(float(item["max_drawdown"]) for item in metrics)
    # Drawdown receives a large penalty; this intentionally favors stability
    # over the single highest historical return.
    return med_sharpe + med_cagr - 2.0 * abs(worst_drawdown)


def optimize_parameters(
    market_data: dict[str, pd.DataFrame],
    benchmark: pd.DataFrame,
    *,
    candidates: Sequence[StrategyParams] | None = None,
    risk: RiskConfig | None = None,
    costs: CostConfig | None = None,
) -> tuple[pd.DataFrame, StrategyParams, SimulationResult]:
    candidates = list(candidates or conservative_grid())
    if not candidates:
        raise ValueError("candidate grid is empty")
    all_dates = sorted(set().union(*(frame.index for frame in market_data.values())))
    if len(all_dates) < 500:
        raise ValueError("at least 500 daily rows are needed for walk-forward optimization")

    cut_45_index = int(len(all_dates) * 0.45)
    cut_625_index = int(len(all_dates) * 0.625)
    cut_80_index = int(len(all_dates) * 0.80)
    cut_80 = all_dates[cut_80_index]
    # Windows are adjacent but never overlap; no boundary trade is counted
    # twice in the validation score.
    validation_windows = (
        (all_dates[cut_45_index], all_dates[cut_625_index - 1]),
        (all_dates[cut_625_index], all_dates[cut_80_index - 1]),
    )

    rows: list[dict[str, object]] = []
    for number, params in enumerate(candidates, start=1):
        window_metrics = []
        for window_start, window_end in validation_windows:
            result = simulate_portfolio(
                market_data,
                benchmark_data=benchmark,
                strategy=params,
                risk=risk,
                costs=costs,
                trade_start=window_start,
                trade_end=window_end,
            )
            window_metrics.append(result.metrics)
        row: dict[str, object] = asdict(params)
        row.update(
            {
                "score": _score(window_metrics),
                "validation_trades": sum(int(m["trades"]) for m in window_metrics),
                "median_sharpe": median(float(m["sharpe_ratio"]) for m in window_metrics),
                "median_cagr": median(float(m["cagr"]) for m in window_metrics),
                "worst_drawdown": min(float(m["max_drawdown"]) for m in window_metrics),
            }
        )
        rows.append(row)
        print(f"Evaluated {number}/{len(candidates)} parameter sets", end="\r")

    ranking = pd.DataFrame(rows).sort_values("score", ascending=False).reset_index(drop=True)
    if ranking.empty or ranking.iloc[0]["score"] == float("-inf"):
        raise RuntimeError("No candidate produced the minimum number of validation trades")
    best_values = ranking.iloc[0]
    best = StrategyParams(
        **{field: best_values[field] for field in asdict(candidates[0])}
    )
    final_test = simulate_portfolio(
        market_data,
        benchmark_data=benchmark,
        strategy=best,
        risk=risk,
        costs=costs,
        trade_start=cut_80,
        trade_end=all_dates[-1],
    )
    print("\nOptimization complete. The last 20% was reserved for final testing.")
    return ranking, best, final_test


def run_optimizer(
    tickers: Iterable[str] = DEFAULT_TICKERS,
    *,
    start: str | None = None,
    end: str | None = None,
    expanded: bool = False,
    output_directory: str | Path = "results/optimizer",
) -> tuple[pd.DataFrame, StrategyParams, SimulationResult]:
    start = start or default_start(10)
    market, errors = download_universe(tickers, start, end)
    if errors:
        print("Skipped symbols:", errors)
    if not market:
        raise RuntimeError("No usable market data")
    benchmark = download_daily_bars(BENCHMARK_TICKER, start, end)
    ranking, best, final_test = optimize_parameters(
        market,
        benchmark,
        candidates=expanded_grid() if expanded else conservative_grid(),
    )
    destination = Path(output_directory)
    destination.mkdir(parents=True, exist_ok=True)
    ranking.to_csv(destination / "parameter_ranking.csv", index=False)
    final_test.trades.to_csv(destination / "final_holdout_trades.csv", index=False)
    final_test.equity_curve.to_csv(destination / "final_holdout_equity.csv")
    pd.DataFrame([final_test.metrics]).to_csv(destination / "final_holdout_metrics.csv", index=False)
    print("Best parameters:", best)
    print("Final holdout metrics:", final_test.metrics)
    return ranking, best, final_test


if __name__ == "__main__":
    run_optimizer()
