"""Friendly command-line entry point. Running without arguments is paper-only."""

import argparse

from backtest import run_backtest
from config import DEFAULT_TICKERS, LIVE_TRADING_AVAILABLE, PAPER_MODE
from data import default_start
from optimizer import run_optimizer
from scanner import print_scan, scan_market


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Daily-bar quantitative research bot (paper simulation only)."
    )
    parser.add_argument(
        "mode",
        nargs="?",
        default="paper",
        choices=("paper", "backtest", "scan", "optimize"),
        help="paper is the safe default",
    )
    parser.add_argument(
        "--tickers",
        nargs="+",
        default=list(DEFAULT_TICKERS),
        help="symbols separated by spaces",
    )
    parser.add_argument("--start", default=default_start(8), help="YYYY-MM-DD")
    parser.add_argument("--end", default=None, help="exclusive YYYY-MM-DD end date")
    parser.add_argument("--results", default="results", help="CSV output folder")
    parser.add_argument(
        "--expanded-grid", action="store_true", help="slower optimizer search"
    )
    return parser


def main() -> None:
    args = build_parser().parse_args()
    if not PAPER_MODE or LIVE_TRADING_AVAILABLE:
        raise RuntimeError("Safety configuration error: this release must remain paper-only")

    print("=" * 66)
    print("PAPER TRADING / HISTORICAL SIMULATION ONLY — NO BROKER ORDERS")
    print("=" * 66)

    if args.mode == "scan":
        print_scan(scan_market(args.tickers, start=args.start, end=args.end))
        return
    if args.mode == "optimize":
        run_optimizer(
            args.tickers,
            start=args.start,
            end=args.end,
            expanded=args.expanded_grid,
            output_directory=f"{args.results}/optimizer",
        )
        return

    # "paper" and "backtest" intentionally use the same safe historical
    # simulator. A future broker adapter cannot silently activate from here.
    run_backtest(
        args.tickers,
        start=args.start,
        end=args.end,
        output_directory=f"{args.results}/backtest",
    )


if __name__ == "__main__":
    main()
