"""Shared, validated settings for the paper-trading project."""

from dataclasses import dataclass


@dataclass(frozen=True)
class RiskConfig:
    """Portfolio limits. Percentages are decimal fractions (0.01 = 1%)."""

    initial_cash: float = 10_000.0
    risk_per_trade: float = 0.005
    max_position_pct: float = 0.20
    max_portfolio_exposure: float = 0.80
    max_open_positions: int = 5
    max_drawdown: float = 0.20
    max_daily_loss: float = 0.03
    atr_stop_multiplier: float = 2.0
    trailing_atr_multiplier: float = 3.0
    min_stop_pct: float = 0.01
    max_stop_pct: float = 0.08
    max_holding_days: int = 20

    def __post_init__(self) -> None:
        if self.initial_cash <= 0:
            raise ValueError("initial_cash must be positive")
        for name in (
            "risk_per_trade",
            "max_position_pct",
            "max_portfolio_exposure",
            "max_drawdown",
            "max_daily_loss",
            "min_stop_pct",
            "max_stop_pct",
        ):
            value = getattr(self, name)
            if not 0 < value < 1:
                raise ValueError(f"{name} must be between 0 and 1")
        if self.max_position_pct > self.max_portfolio_exposure:
            raise ValueError("max_position_pct cannot exceed max_portfolio_exposure")
        if self.min_stop_pct > self.max_stop_pct:
            raise ValueError("min_stop_pct cannot exceed max_stop_pct")
        if self.max_open_positions < 1 or self.max_holding_days < 1:
            raise ValueError("position and holding limits must be at least 1")
        if self.atr_stop_multiplier <= 0 or self.trailing_atr_multiplier <= 0:
            raise ValueError("ATR multipliers must be positive")


@dataclass(frozen=True)
class CostConfig:
    """Simple trading-friction model applied on both entry and exit."""

    slippage_bps: float = 10.0
    commission_bps: float = 1.0

    def __post_init__(self) -> None:
        if self.slippage_bps < 0 or self.commission_bps < 0:
            raise ValueError("costs cannot be negative")
        if self.slippage_bps >= 1_000 or self.commission_bps >= 1_000:
            raise ValueError("costs appear to use the wrong units; expected basis points")


DEFAULT_TICKERS = (
    "AAPL",
    "MSFT",
    "NVDA",
    "AMZN",
    "GOOGL",
    "META",
    "TSLA",
    "AMD",
    "AVGO",
    "NFLX",
)

BENCHMARK_TICKER = "SPY"
PAPER_MODE = True
LIVE_TRADING_AVAILABLE = False
